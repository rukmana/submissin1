package com.jelekong.aplikasifootbalclub

data class FootballClubItem (val name : String?, val image : Int?, val detail : String?)